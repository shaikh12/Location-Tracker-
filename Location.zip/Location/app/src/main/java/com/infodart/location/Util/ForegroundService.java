package com.infodart.location.Util;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;


import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.infodart.location.Activity.MapsActivity;
import com.infodart.location.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ForegroundService extends Service {

    public static final String CHANNEL_ID = "ForegroundService";
    FirebaseDatabase database;
    Location location;
    private LatLng latLng;

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public IBinder onBind(Intent intent) {
       return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        createNotificationChannel();
        Intent notificationIntent = new Intent(this, MapsActivity.class);
        PendingIntent pendingIntent=PendingIntent.getActivity(this, 0, notificationIntent, 0);

        if(location!= null){
            //passing the value of longitude & latitude in the helper class
            LocationHelper helper = new LocationHelper(
                    location.getLongitude(),
                    location.getLatitude(),new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                    .format(Calendar.getInstance().getTime()));

            database = FirebaseDatabase.getInstance();
            FirebaseDatabase.getInstance().getReference("location-7317e").push()
                    .setValue(helper).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {

                    if (task.isSuccessful()){
                        Toast.makeText(ForegroundService.this, "Location Saved", Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(ForegroundService.this, "Location Not Saved", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        Bitmap icon = BitmapFactory.decodeResource(getResources(),
                R.drawable.map);

        Notification notification =new NotificationCompat.Builder(this,CHANNEL_ID)
                    .setContentTitle("Location")
                    .setContentText("Location Changes Continuously")
                    .setSmallIcon(R.drawable.ic_location)
                    .setLargeIcon(Bitmap.createScaledBitmap(icon, 140, 160, false))
                    .setContentIntent(pendingIntent)
                    .setOngoing(true)

                    .build();

        startForeground(Constants.NOTIFICATION_ID.FOREGROUND_SERVICE, notification);

        if(intent.getAction().equals(Constants.ACTION.STOPFOREGROUND_ACTION)){
            stopForeground(true);
            stopSelf();
        }

        return START_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(CHANNEL_ID, "Foreground Service Channel", NotificationManager.IMPORTANCE_DEFAULT);

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i("Foreground Service", "In onDestroy");
    }
}
