package com.infodart.location.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.core.Constants;
import com.infodart.location.Adapter.Firebase_Adapter;
import com.infodart.location.R;
import com.infodart.location.Util.ForegroundService;
import com.infodart.location.Util.LocationHelper;

import java.util.ArrayList;
import java.util.List;

public class DataShow_Activity extends AppCompatActivity  {

    private DatabaseReference mDatabase;
    Firebase_Adapter adapter;
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_show_);

        recyclerView = findViewById(R.id.recyclerView);
        layoutManager = new LinearLayoutManager(context,LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutManager);

        mDatabase = FirebaseDatabase.getInstance().getReference()
                .child("location-7317e");

        ValueEventListener valueEventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                 List notes= new ArrayList<>();

                for (DataSnapshot LocationHelper : dataSnapshot.getChildren())
                {
                    Double longitude = Double.parseDouble(LocationHelper.child("longitude").getValue().toString());
                    Double latitude = Double.parseDouble( LocationHelper.child("latitude").getValue().toString());
                    String time = String.valueOf(LocationHelper.child("time").getValue());

                    LocationHelper locationHelper = new LocationHelper(longitude,latitude,time);
                    notes.add(locationHelper);

                }
                adapter = new Firebase_Adapter(DataShow_Activity.this,notes);
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(DataShow_Activity.this, "OnCancelled method called", Toast.LENGTH_SHORT).show();
            }
        };
        mDatabase.addListenerForSingleValueEvent(valueEventListener);
    }

}
