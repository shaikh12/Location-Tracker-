package com.infodart.location.Util;

public class Constants {

    public interface ACTION {
        public static String STARTFOREGROUND_ACTION = "com.infodart.location.action.startforeground";
        public static String STOPFOREGROUND_ACTION = "com.infodart.location.action.stopforeground";
    }
    public interface NOTIFICATION_ID {
        public static int FOREGROUND_SERVICE = 786;
    }
}
