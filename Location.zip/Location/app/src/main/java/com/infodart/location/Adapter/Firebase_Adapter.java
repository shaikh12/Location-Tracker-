package com.infodart.location.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.infodart.location.R;
import com.infodart.location.Util.LocationHelper;

import java.util.List;

public class Firebase_Adapter extends RecyclerView.Adapter<Firebase_Adapter.MyHolder> {

    public Context context;
    List<LocationHelper> arrayList;
    private LayoutInflater inflater;


    public Firebase_Adapter(Context context, List<LocationHelper> arrayList){
        this.context = context;
        this.arrayList = arrayList;
        inflater = LayoutInflater.from(context);
    }


    @Override
    public MyHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = inflater.inflate(R.layout.custom_listitem,parent,false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder( MyHolder holder, int position) {

        holder.txt_date.setText(arrayList.get(position).getTime());
        holder.txt_lat.setText(String.valueOf("Latitude = "+ arrayList.get(position).getLatitude()));
        holder.txt_long.setText(String.valueOf( "Longitude = "+arrayList.get(position).getLongitude()));
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {

        TextView txt_date,txt_lat,txt_long;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            txt_date = itemView.findViewById(R.id.txt_date);
            txt_lat = itemView.findViewById(R.id.txt_lat);
            txt_long = itemView.findViewById(R.id.txt_long);
        }
    }
}
